function selectPokemon() {
    const pokemon = document.querySelector("#pokemons-select").value;
  
    let pokemonData = {
      name: "",
      imageUrl: "",
      power: "",
      types: [],
    };
    switch (pokemon) {
      case "1":
        pokemonData = {
          name: "bulbasaur",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png",
          power: "overgrow",
          types: ["grass", "poison"],
        };
        break;
      case "2":
        pokemonData = {
          name: "ivysaur",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/2.png",
          power: "overgrow",
          types: ["grass", "poison"],
        };
        break;
      case "3":
        pokemonData = {
          name: "venusaur",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/3.png",
          power: "overgrow",
          types: ["grass", "poison"],
        };
        break;
      case "4":
        pokemonData = {
          name: "charmander",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/4.png",
          power: "Blaze",
          types: ["fire"],
        };
        break;
      case "5":
        pokemonData = {
          name: "charmeleon",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/5.png",
          power: "Blaze",
          types: ["fire"],
        };
        break;
      case "0":
        pokemonData = {
          name: "",
          imageUrl: "",
          power: "",
          types: [],
        };
        break;
    }
  
    document.querySelector(".pokemon-container").innerHTML = `
        <h2>Name: <span>${pokemonData.name}</span></h2>
        <img src="${pokemonData.imageUrl}" >
        <h3>Power: <span>${pokemonData.power}</span><h3>
        <h3>Types:</h3>
        <ul>
          ${pokemonData.types.map((type) => {
            return `<li>${type}</li>`;
          })}  
        </ul>
      `;
  }
  function selectPokemon() {
    const pokemon = document.querySelector("#pokemons-select").value;
  
    let pokemonData = {
      name: "",
      imageUrl: "",
      power: "",
      types: [],
    };
    switch (pokemon) {
      case "1":
        pokemonData = {
          name: "bulbasaur",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png",
          power: "overgrow",
          types: ["grass", "poison"],
        };
        break;
      case "2":
        pokemonData = {
          name: "ivysaur",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/2.png",
          power: "overgrow",
          types: ["grass", "poison"],
        };
        break;
      case "3":
        pokemonData = {
          name: "venusaur",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/3.png",
          power: "overgrow",
          types: ["grass", "poison"],
        };
        break;
      case "4":
        pokemonData = {
          name: "charmander",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/4.png",
          power: "Blaze",
          types: ["fire"],
        };
        break;
      case "5":
        pokemonData = {
          name: "charmeleon",
          imageUrl:
            "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/5.png",
          power: "Blaze",
          types: ["fire"],
        };
        break;
      case "0":
        pokemonData = {
          name: "",
          imageUrl: "",
          power: "",
          types: [],
        };
        break;
    }
  
    document.querySelector(".pokemon-container").innerHTML = `
        <h2>Name: <span>${pokemonData.name}</span></h2>
        <img src="${pokemonData.imageUrl}" >
        <h3>Power: <span>${pokemonData.power}</span><h3>
        <h3>Types:</h3>
        <ul>
          ${pokemonData.types.map((type) => {
            return `<li>${type}</li>`;
          })}  
        </ul>
      `;
  }