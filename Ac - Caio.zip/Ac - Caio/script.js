function logar() {
    const nomeUsuario = document.getElementById("nomeUsuario").value;
    const senhaUsuario = document.getElementById("senhaUsuario").value;
  if (nomeUsuario === "pokemon" && senhaUsuario === "pokemon" ) {
    alert("Login efetuado com sucesso!");
    window.location.href = "#"
  }
  else if (nomeUsuario === null || senhaUsuario === null){
    alert("O campo não pode estar vazio!")
  }else if(nomeUsuario != "pokemon" || senhaUsuario != "pokemon" ){
    alert("Login ou senha incorretos!")
  }
}
function cadastro() {
    const nomeCadastro = document.getElementById("nomeCadastro").value;
    const emailUsuario = document.getElementById("emailUsuario").value;
    const idadeCadastro = document.getElementById("idadeCadastro").value;
    const senhaCadastro = document.getElementById("senhaCadastro").value;
    const confirmacaoSenha = document.getElementById("confirmacaoSenha").value;
    const generoCadastro = document.getElementById("generoCadastro").value;

 
    if (nomeCadastro === null || emailUsuario === null || idadeCadastro === null || senhaCadastro === null || confirmacaoSenha === null || generoCadastro === null){
    alert("Todos os campos devem ser prenchidos");
  }
  else if (nomeCadastro.length < 2 ){
    alert("Seu nome deve ter mais doque 2 letras!")
  }else if(idadeCadastro < 0 || idadeCadastro > 100 ){
    alert("Sua idade não pode ser menor que 0 ou maior que 100")
  }else if(senhaCadastro < 6){
    alert("Sua senha não pode ter menos de 6 digitos ")
  }else if(senhaCadastro != confirmacaoSenha){
    alert("Suas confirmação de senha não estão iguais")
  }else if(generoCadastro.toLowerCase() != 'f' && generoCadastro.toLowerCase() != 'm'){
    alert("Escolha um gênero entre f ou m ")
  }
  else {
    window.location.href = './pokedex'
  }
}
 